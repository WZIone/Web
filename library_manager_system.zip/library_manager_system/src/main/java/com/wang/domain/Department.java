package com.wang.domain;

import lombok.Data;

@Data
public class Department {
    private Integer deptId;

    private String deptName;
}